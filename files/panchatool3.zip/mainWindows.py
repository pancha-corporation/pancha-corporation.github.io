import os
import platform
import time
import sys
import json
import subprocess
import random
import ctypes

if platform.system() != "Windows":
    print("Это приложение предназначено только для Windows.")
    sys.exit(1)

try:
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
except:
    pass

try:
    import winreg
except ImportError:
    print("Не удалось импортировать модуль winreg.")
    sys.exit(1)

try:
    import pygame
    pygame.mixer.init()
    MIXER_AVAILABLE = True
except:
    MIXER_AVAILABLE = False
    pygame = None

ESC = chr(27)
BOLD = ESC + "[1m"
BOLD_ITALIC = ESC + "[1m" + ESC + "[3m"
RESET = ESC + "[0m"

CONFIG_FILE = "tool_config.json"
LANG_FILE = "language.json"

CPU_FAKE_NAME = "panchynez na sperme mamnyi tomasa"
GPU_FAKE_NAME = "gnilaya gt610"

config = {}
LOCALES_DATA = {}
COLOR_RIGHT = (100, 149, 237)
COLOR_LEFT  = (238, 130, 238)

MINIMAL_FALLBACK_RU = {
    'title': 'pancha tool3',
    'menu_1': '1. хаук спотыфай',
    'menu_2': '2. опгреид железа',
    'menu_3': '3. взулом баунков РФ',
    'menu_4': '4. рецепт чифира',
    'menu_5': '5. настройки',
    'menu_6': '6. выход',
    'settings_title': 'НАСТРОЙКИ',
    'theme_choice': 'Выбрать тему',
    'language_choice': 'Выбрать язык',
    'back': 'Назад',
    'invalid_input': 'Неверный ввод, попробуйте снова.',
    'init_warning': '⚠ Инициализация была пропущена. Некоторые функции могут работать нестабильно.',
    'press_enter': 'Нажмите Enter, чтобы продолжить...',
    'choose_language': 'ВЫБОР ЯЗЫКА',
    'choose_theme': 'ВЫБОР ТЕМЫ',
    'language_ru': 'Русский',
    'language_en': 'English',
    'language_zh': '中文',
    'theme_blue': 'Сине-фиолетовая',
    'theme_red': 'Красно-белая',
    'theme_green': 'Зелёно-жёлтая',
    'init_disabled': 'Отключить инициализацию',
    'init_status_on': 'ВКЛ',
    'init_status_off': 'ВЫКЛ',
    'exit': 'Выход из программы.',
    'choose_option': ' > ',
    'info_title': 'Информация',
    'info_text': 'pancha tool 3 (base version)\nканал pancha corporation - t.me/PanchaCorporation\nканал создателей - t.me/scary_cocoa\nдата выхода - 20.02.26\nсвязь с pancha corporation / создателем сетки pancha tool -\n@panchacorporationbot\ngmail для связи - panchaCorporation@gmail.com'
}

def _(key):
    lang = config.get("language", "ru")
    return LOCALES_DATA.get(lang, {}).get(key, key)

def load_config():
    default_config = {
        "init_disabled": False,
        "theme": "blue-purple",
        "language": "ru",
        "original_cpu_name": None,
        "original_gpu_name": None
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                cfg = json.load(f)
                if "original_cpu_name" not in cfg:
                    cfg["original_cpu_name"] = None
                if "original_gpu_name" not in cfg:
                    cfg["original_gpu_name"] = None
                return cfg
        except:
            return default_config
    return default_config

def save_config(cfg):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(cfg, f)

def load_language_file():
    required_keys = [
        'title', 'menu_1', 'menu_2', 'menu_3', 'menu_4', 'menu_5', 'menu_6',
        'settings_title', 'theme_choice', 'language_choice', 'back',
        'invalid_input', 'init_warning', 'press_enter',
        'choose_language', 'choose_theme', 'language_ru', 'language_en', 'language_zh',
        'theme_blue', 'theme_red', 'theme_green', 'init_disabled',
        'init_status_on', 'init_status_off', 'exit', 'choose_option',
        'info_title', 'info_text'
    ]
    if os.path.exists(LANG_FILE):
        try:
            with open(LANG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            valid = True
            for lang in ('ru', 'en', 'zh'):
                if lang not in data:
                    valid = False
                    break
                for key in required_keys:
                    if key not in data[lang]:
                        valid = False
                        break
                if not valid:
                    break
            if valid:
                return data
        except:
            pass
    return {'ru': MINIMAL_FALLBACK_RU, 'en': MINIMAL_FALLBACK_RU, 'zh': MINIMAL_FALLBACK_RU}

def check_dependencies():
    missing = []
    required_keys = [
        'title', 'menu_1', 'menu_2', 'menu_3', 'menu_4', 'menu_5', 'menu_6',
        'settings_title', 'theme_choice', 'language_choice', 'back',
        'invalid_input', 'init_warning', 'press_enter',
        'choose_language', 'choose_theme', 'language_ru', 'language_en', 'language_zh',
        'theme_blue', 'theme_red', 'theme_green', 'init_disabled',
        'init_status_on', 'init_status_off', 'exit', 'choose_option',
        'info_title', 'info_text'
    ]
    lang_ok = False
    if os.path.exists(LANG_FILE):
        try:
            with open(LANG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            valid = True
            for lang in ('ru', 'en', 'zh'):
                if lang not in data:
                    valid = False
                    break
                for key in required_keys:
                    if key not in data[lang]:
                        valid = False
                        break
                if not valid:
                    break
            if valid:
                lang_ok = True
        except:
            pass
    if not lang_ok:
        missing.append("language.json — файл локализации (будет использован встроенный русский текст)")

    if not os.path.exists(CONFIG_FILE):
        missing.append("tool_config.json — файл настроек (будет создан автоматически)")

    script_dir = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.join(script_dir, "src")
    music_files = ["song1.mp3", "song2.mp3", "song3.mp3", "song4.mp3",
                   "song5.mp3", "song6.mp3", "song7.mp3"]
    missing_music = [s for s in music_files if not os.path.exists(os.path.join(src_dir, s))]
    if missing_music:
        missing.append(f"музыкальные файлы — отсутствует {len(missing_music)} из 7 в папке src/")

    return missing

def apply_theme(theme_name):
    global COLOR_RIGHT, COLOR_LEFT
    if theme_name == "blue-purple":
        COLOR_RIGHT = (100, 149, 237)
        COLOR_LEFT  = (238, 130, 238)
    elif theme_name == "red-white":
        COLOR_RIGHT = (255, 0, 0)
        COLOR_LEFT  = (255, 200, 200)
    elif theme_name == "green-yellow":
        COLOR_RIGHT = (0, 255, 0)
        COLOR_LEFT  = (255, 255, 0)
    else:
        COLOR_RIGHT = (100, 149, 237)
        COLOR_LEFT  = (238, 130, 238)

def get_terminal_width():
    try:
        return os.get_terminal_size().columns
    except:
        return 80

def clear_screen():
    os.system('cls')

def initialization():
    if not config.get("init_disabled", False):
        print("Initializing", end="", flush=True)
        for _ in range(3):
            time.sleep(0.5)
            print(".", end="", flush=True)
        time.sleep(0.5)
        print()
    clear_screen()

def gradient_color_for_pos(pos, length):
    if length <= 1:
        ratio = 0
    else:
        ratio = 1 - (pos / (length - 1))
    r = int(COLOR_RIGHT[0] + (COLOR_LEFT[0] - COLOR_RIGHT[0]) * ratio)
    g = int(COLOR_RIGHT[1] + (COLOR_LEFT[1] - COLOR_RIGHT[1]) * ratio)
    b = int(COLOR_RIGHT[2] + (COLOR_LEFT[2] - COLOR_RIGHT[2]) * ratio)
    return ESC + f"[38;2;{r};{g};{b}m"

def print_colored_line(line, padding_spaces, style_func=None):
    sys.stdout.write(padding_spaces)
    length = len(line)
    for i, ch in enumerate(line):
        color = gradient_color_for_pos(i, length)
        style = style_func(i) if style_func else ""
        sys.stdout.write(color + style + ch + RESET)
    sys.stdout.write("\n")
    sys.stdout.flush()

def gradient_input(prompt):
    term_width = get_terminal_width()
    box_width = 40
    left_padding = (term_width - box_width) // 2
    padding_spaces = " " * left_padding
    sys.stdout.write(padding_spaces)
    plen = len(prompt)
    for i, ch in enumerate(prompt):
        color = gradient_color_for_pos(i, plen)
        sys.stdout.write(color + BOLD_ITALIC + ch + RESET)
    sys.stdout.flush()
    return input().strip()

def normalize_choice(choice):
    choice = choice.strip()
    chars_to_remove = ",.;:'\"[]{}()_-+=<>/?\\|!@#$%^&*"
    for ch in chars_to_remove:
        choice = choice.replace(ch, '')
    return choice

def show_dependency_warning(missing):
    clear_screen()
    term_width = get_terminal_width()
    box_width = 55
    left_padding = max(0, (term_width - box_width) // 2)
    padding_spaces = " " * left_padding

    print_colored_line("ПРОВЕРКА ЗАВИСИМОСТЕЙ", padding_spaces, lambda i: BOLD)
    print_colored_line("─" * box_width, padding_spaces)
    print()
    print_colored_line("Некоторые файлы зависимостей не были найдены:", padding_spaces, lambda i: BOLD_ITALIC)
    print()
    for item in missing:
        print_colored_line("  • " + item, padding_spaces, lambda i: BOLD_ITALIC)
    print()
    print_colored_line("Некоторые функции могут не работать.", padding_spaces, lambda i: BOLD_ITALIC)
    print()
    print_colored_line("Продолжить?", padding_spaces, lambda i: BOLD_ITALIC)
    print_colored_line("  1. Да", padding_spaces, lambda i: BOLD_ITALIC)
    print_colored_line("  2. Нет", padding_spaces, lambda i: BOLD_ITALIC)
    print_colored_line("─" * box_width, padding_spaces)

    choice = gradient_input(" > ")
    return normalize_choice(choice) == "1"

def print_ui():
    term_width = get_terminal_width()
    box_width = 40
    title = _('title')
    title_len = len(title)

    left_frame = "╔══"
    right_frame = "══╗"
    space_total = box_width - len(left_frame) - len(right_frame) - title_len
    left_space = space_total // 2
    right_space = space_total - left_space

    top_left = left_frame + " " * left_space
    top_title = title
    top_right = " " * right_space + right_frame
    top_full = top_left + top_title + top_right

    def top_style(i):
        if i >= len(top_left) and i < len(top_left) + len(top_title):
            return BOLD
        return ""

    menu_items = [
        _('menu_1') + '.',
        _('menu_2') + '.',
        _('menu_3') + '.',
        _('menu_4') + '.',
        _('menu_5') + '.',
        _('menu_6') + '.'
    ]
    indented_menu = ["    " + item for item in menu_items]
    bottom_line = "╚" + "═" * (box_width - 2) + "╝"
    interface_lines = [top_full] + indented_menu + [bottom_line]

    left_padding = (term_width - box_width) // 2
    padding_spaces = " " * left_padding

    for idx, line in enumerate(interface_lines):
        if idx == 0:
            print_colored_line(line, padding_spaces, top_style)
        elif 1 <= idx <= len(menu_items):
            print_colored_line(line, padding_spaces, lambda i: BOLD_ITALIC)
        else:
            print_colored_line(line, padding_spaces)

    if config.get("init_disabled"):
        warning = _('init_warning')
        warn_padding = " " * ((term_width - len(warning)) // 2)
        print_colored_line(warning, warn_padding, lambda i: BOLD_ITALIC)

    return padding_spaces, term_width, box_width

def get_original_cpu_name():
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        name, _ = winreg.QueryValueEx(key, "ProcessorNameString")
        winreg.CloseKey(key)
        return name
    except:
        return "Unknown CPU"

def get_original_gpu_name():
    try:
        path = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000"
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ)
        try:
            name, _ = winreg.QueryValueEx(key, "DriverDesc")
            winreg.CloseKey(key)
            return name
        except:
            winreg.CloseKey(key)
    except:
        pass
    return "Unknown GPU"

def set_cpu_name(new_name):
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                              r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
                              0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "ProcessorNameString", 0, winreg.REG_SZ, new_name)
        winreg.CloseKey(key)
        return True
    except:
        return False

def set_gpu_name(new_name):
    modified = False
    paths = [
        r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000",
        r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0001",
    ]
    for path in paths:
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0,
                                 winreg.KEY_SET_VALUE | winreg.KEY_READ)
            try:
                winreg.SetValueEx(key, "DriverDesc", 0, winreg.REG_SZ, new_name)
                modified = True
            except:
                pass
            try:
                subkey = winreg.OpenKey(key, "HardwareInformation", 0, winreg.KEY_SET_VALUE)
                for val_name in ("AdapterString", "ChipType"):
                    try:
                        winreg.SetValueEx(subkey, val_name, 0, winreg.REG_SZ, new_name)
                        modified = True
                    except:
                        pass
                winreg.CloseKey(subkey)
            except:
                pass
            winreg.CloseKey(key)
        except:
            continue
    return modified

def hardware_upgrade_submenu():
    options = [
        "1. апгреид видеоркаты",
        "2. апгреид процессора",
        "3. полный апгрейд",
        "4. вернуть назад"
    ]

    if config.get("original_cpu_name") is None:
        config["original_cpu_name"] = get_original_cpu_name()
    if config.get("original_gpu_name") is None:
        config["original_gpu_name"] = get_original_gpu_name()
    save_config(config)

    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        title = "ОПГРЕИД ЖЕЛЕЗА"
        print_colored_line(title, padding_spaces, lambda i: BOLD)
        sep = "─" * box_width
        print_colored_line(sep, padding_spaces)

        cpu_status = " (изменён)" if config.get("original_cpu_name") != get_original_cpu_name() else ""
        gpu_status = " (изменён)" if config.get("original_gpu_name") != get_original_gpu_name() else ""

        print_colored_line("    1. апгреид видеоркаты" + gpu_status, padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line("    2. апгреид процессора" + cpu_status, padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line("    3. полный апгрейд", padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line("    4. вернуть назад", padding_spaces, lambda i: BOLD_ITALIC)

        back_text = "0. " + _('back') + "."
        print_colored_line("    " + back_text, padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line(sep, padding_spaces)

        choice = gradient_input(" > ")
        choice = normalize_choice(choice)

        if choice == "0":
            break
        elif choice == "1":
            gpu_ok = set_gpu_name(GPU_FAKE_NAME)
            clear_screen()
            print("\n" * 2, end='')
            if gpu_ok:
                print_colored_line(f"Видеокарта изменена на '{GPU_FAKE_NAME}'",
                                   padding_spaces, lambda i: BOLD_ITALIC)
            else:
                print_colored_line("Попытка изменить видеокарту выполнена",
                                   padding_spaces, lambda i: BOLD_ITALIC)
                print_colored_line("(возможно не сработало)",
                                   padding_spaces, lambda i: BOLD_ITALIC)
            print()
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            input()
        elif choice == "2":
            cpu_ok = set_cpu_name(CPU_FAKE_NAME)
            clear_screen()
            print("\n" * 2, end='')
            if cpu_ok:
                print_colored_line(f"Процессор изменён на '{CPU_FAKE_NAME}'",
                                   padding_spaces, lambda i: BOLD_ITALIC)
                print_colored_line("(изменения вступят в силу после перезагрузки)",
                                   padding_spaces, lambda i: BOLD_ITALIC)
            else:
                print_colored_line("Попытка изменить процессор выполнена",
                                   padding_spaces, lambda i: BOLD_ITALIC)
                print_colored_line("(возможно не сработало)",
                                   padding_spaces, lambda i: BOLD_ITALIC)
            print()
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            input()
        elif choice == "3":
            gpu_ok = set_gpu_name(GPU_FAKE_NAME)
            cpu_ok = set_cpu_name(CPU_FAKE_NAME)
            clear_screen()
            print("\n" * 2, end='')
            print_colored_line("Попытка полного апгрейда выполнена",
                               padding_spaces, lambda i: BOLD_ITALIC)
            print_colored_line("(возможно не сработало)",
                               padding_spaces, lambda i: BOLD_ITALIC)
            print()
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            input()
        elif choice == "4":
            if config.get("original_cpu_name"):
                set_cpu_name(config["original_cpu_name"])
            if config.get("original_gpu_name") and config["original_gpu_name"] != "Unknown GPU":
                set_gpu_name(config["original_gpu_name"])
            clear_screen()
            print("\n" * 2, end='')
            print_colored_line("Попытка вернуть оригинальные названия выполнена",
                               padding_spaces, lambda i: BOLD_ITALIC)
            print_colored_line("(возможно не сработало)",
                               padding_spaces, lambda i: BOLD_ITALIC)
            print()
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            input()
        else:
            print("\n" * 2, end='')
            print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
            time.sleep(1)

def play_music_player(playlist, playlist_name):
    if not MIXER_AVAILABLE:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding
        print_colored_line("Библиотека pygame.mixer не доступна. Установите pygame: pip install pygame", padding_spaces, lambda i: BOLD_ITALIC)
        print()
        print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
        input()
        return

    if not playlist:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding
        print_colored_line("Нет доступных музыкальных файлов.", padding_spaces, lambda i: BOLD_ITALIC)
        print()
        print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
        input()
        return

    current_index = 0
    paused = False
    pygame.mixer.music.load(playlist[current_index])
    pygame.mixer.music.play()

    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        print_colored_line(f"СЕЙЧАС ИГРАЕТ: {playlist_name}", padding_spaces, lambda i: BOLD)
        sep = "─" * box_width
        print_colored_line(sep, padding_spaces)

        status = "Пауза" if paused else "Играет"
        print_colored_line("    " + f"Статус: {status}", padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line("", padding_spaces)

        menu_options = ["1. пауза", "2. возобновить", "3. следующий", "4. предыдущий", "0. выход"]
        for opt in menu_options:
            print_colored_line("    " + opt, padding_spaces, lambda i: BOLD_ITALIC)

        print_colored_line(sep, padding_spaces)

        if not paused and not pygame.mixer.music.get_busy():
            current_index = (current_index + 1) % len(playlist)
            pygame.mixer.music.load(playlist[current_index])
            pygame.mixer.music.play()

        choice = gradient_input(" > ")
        choice = normalize_choice(choice)

        if choice == "0":
            pygame.mixer.music.stop()
            break
        elif choice == "1":
            if not paused:
                pygame.mixer.music.pause()
                paused = True
        elif choice == "2":
            if paused:
                pygame.mixer.music.unpause()
                paused = False
        elif choice == "3":
            current_index = (current_index + 1) % len(playlist)
            pygame.mixer.music.load(playlist[current_index])
            pygame.mixer.music.play()
            paused = False
        elif choice == "4":
            current_index = (current_index - 1) % len(playlist)
            pygame.mixer.music.load(playlist[current_index])
            pygame.mixer.music.play()
            paused = False

def hawk_spotify_song_base():
    options = ["1. хуак круты молодежы хиты 2025", "2. хуак панча корпарацан хиты 2026"]

    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        print_colored_line("ХАУК СПОТЫФАЙ - БАЗА ДАННЫХ", padding_spaces, lambda i: BOLD)
        sep = "─" * box_width
        print_colored_line(sep, padding_spaces)

        for opt in options:
            print_colored_line("    " + opt, padding_spaces, lambda i: BOLD_ITALIC)

        back_text = "0. " + _('back') + "."
        print_colored_line("    " + back_text, padding_spaces, lambda i: BOLD_ITALIC)
        print_colored_line(sep, padding_spaces)

        choice = gradient_input(_('choose_option'))
        choice = normalize_choice(choice)

        if choice == "0":
            break
        elif choice == "1":
            script_dir = os.path.dirname(os.path.abspath(__file__))
            src_dir = os.path.join(script_dir, "src")
            os.makedirs(src_dir, exist_ok=True)
            playlist_files = []
            missing_files = []
            for song in ["song4.mp3", "song5.mp3", "song6.mp3", "song7.mp3"]:
                path = os.path.join(src_dir, song)
                if os.path.exists(path):
                    playlist_files.append(path)
                else:
                    missing_files.append(song)
            if missing_files:
                clear_screen()
                print_colored_line("Отсутствуют файлы для плейлиста:", padding_spaces, lambda i: BOLD_ITALIC)
                for f in missing_files:
                    print_colored_line(f"  - {f}", padding_spaces, lambda i: BOLD_ITALIC)
                print()
                print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
                input()
                continue
            play_music_player(playlist_files, "хуак круты молодежы хиты 2025")
        elif choice == "2":
            script_dir = os.path.dirname(os.path.abspath(__file__))
            src_dir = os.path.join(script_dir, "src")
            os.makedirs(src_dir, exist_ok=True)
            playlist_files = []
            missing_files = []
            for song in ["song1.mp3", "song2.mp3", "song3.mp3"]:
                path = os.path.join(src_dir, song)
                if os.path.exists(path):
                    playlist_files.append(path)
                else:
                    missing_files.append(song)
            if missing_files:
                clear_screen()
                print_colored_line("Отсутствуют файлы для плейлиста:", padding_spaces, lambda i: BOLD_ITALIC)
                for f in missing_files:
                    print_colored_line(f"  - {f}", padding_spaces, lambda i: BOLD_ITALIC)
                print()
                print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
                input()
                continue
            play_music_player(playlist_files, "хуак панча корпарацан хиты 2026")
        else:
            print("\n" * 2, end='')
            print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
            time.sleep(1)

def hack_russian_banks_submenu():
    clear_screen()
    term_width = get_terminal_width()
    box_width = 40
    left_padding = (term_width - box_width) // 2
    padding_spaces = " " * left_padding
    print_colored_line("Данная функция работает только на Linux системах.", padding_spaces, lambda i: BOLD_ITALIC)
    print()
    print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
    input()

def info_menu():
    clear_screen()
    term_width = get_terminal_width()
    box_width = 40
    left_padding = (term_width - box_width) // 2
    padding_spaces = " " * left_padding

    print_colored_line(_('info_title'), padding_spaces, lambda i: BOLD)
    print_colored_line("─" * box_width, padding_spaces)

    info_text = _('info_text')
    for line in info_text.split('\n'):
        print_colored_line(line, padding_spaces, lambda i: BOLD_ITALIC)

    print()
    print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
    input()

def settings_menu():
    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        print_colored_line(_('settings_title'), padding_spaces, lambda i: BOLD)
        print_colored_line("─" * box_width, padding_spaces)

        menu_index = 1
        theme_names = {
            "blue-purple": _('theme_blue'),
            "red-white": _('theme_red'),
            "green-yellow": _('theme_green')
        }
        current_theme = theme_names.get(config.get("theme", "blue-purple"), _('theme_blue'))
        print_colored_line(f"{menu_index}. {_('theme_choice')}. ({current_theme})", padding_spaces, lambda i: BOLD_ITALIC)
        menu_index += 1

        lang_names = {"ru": _('language_ru'), "en": _('language_en'), "zh": _('language_zh')}
        current_lang = lang_names.get(config.get("language", "ru"), _('language_ru'))
        print_colored_line(f"{menu_index}. {_('language_choice')}. ({current_lang})", padding_spaces, lambda i: BOLD_ITALIC)
        menu_index += 1

        print_colored_line(f"{menu_index}. {_('info_title')}.", padding_spaces, lambda i: BOLD_ITALIC)
        menu_index += 1

        print_colored_line(f"{menu_index}. {_('back')}.", padding_spaces, lambda i: BOLD_ITALIC)

        print_colored_line("─" * box_width, padding_spaces)

        choice = gradient_input(" > ")
        choice = normalize_choice(choice)
        try:
            ci = int(choice)
        except ValueError:
            ci = -1

        if ci == 1:
            theme_submenu()
        elif ci == 2:
            language_submenu()
        elif ci == 3:
            info_menu()
        elif ci == 4:
            break
        else:
            print("\n" * 2, end='')
            print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
            time.sleep(1)

def theme_submenu():
    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        print_colored_line(_('choose_theme'), padding_spaces, lambda i: BOLD)
        print_colored_line("─" * box_width, padding_spaces)

        themes = [
            ("1. " + _('theme_blue'), "blue-purple"),
            ("2. " + _('theme_red'), "red-white"),
            ("3. " + _('theme_green'), "green-yellow"),
            ("4. " + _('back'), None)
        ]
        for text, _unused in themes:
            print_colored_line("    " + text, padding_spaces, lambda i: BOLD_ITALIC)

        print_colored_line("─" * box_width, padding_spaces)

        choice = gradient_input(" > ")
        choice = normalize_choice(choice)

        for text, theme_key in themes:
            if choice == text[0]:
                if theme_key:
                    config["theme"] = theme_key
                    apply_theme(theme_key)
                    save_config(config)
                    print("\n" * 2, end='')
                    print_colored_line(_('choose_theme') + " > " + _('back'), padding_spaces, lambda i: BOLD_ITALIC)
                    time.sleep(1)
                    return
                else:
                    return
        print("\n" * 2, end='')
        print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
        time.sleep(1)

def language_submenu():
    while True:
        clear_screen()
        term_width = get_terminal_width()
        box_width = 40
        left_padding = (term_width - box_width) // 2
        padding_spaces = " " * left_padding

        print_colored_line(_('choose_language'), padding_spaces, lambda i: BOLD)
        print_colored_line("─" * box_width, padding_spaces)

        languages = [
            ("1. " + _('language_ru'), "ru"),
            ("2. " + _('language_en'), "en"),
            ("3. " + _('language_zh'), "zh"),
            ("4. " + _('back'), None)
        ]
        for text, _unused in languages:
            print_colored_line("    " + text, padding_spaces, lambda i: BOLD_ITALIC)

        print_colored_line("─" * box_width, padding_spaces)

        choice = gradient_input(" > ")
        choice = normalize_choice(choice)

        for text, lang_key in languages:
            if choice == text[0]:
                if lang_key:
                    config["language"] = lang_key
                    save_config(config)
                    print("\n" * 2, end='')
                    print_colored_line(_('choose_language') + " > " + _('back'), padding_spaces, lambda i: BOLD_ITALIC)
                    time.sleep(1)
                    return
                else:
                    return
        print("\n" * 2, end='')
        print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
        time.sleep(1)

def main():
    global config, LOCALES_DATA
    config = load_config()

    missing = check_dependencies()
    if missing:
        if not show_dependency_warning(missing):
            sys.exit(0)

    LOCALES_DATA = load_language_file()
    apply_theme(config.get("theme", "blue-purple"))
    initialization()

    while True:
        padding_spaces, term_width, box_width = print_ui()

        raw_choice = gradient_input(_('choose_option'))
        choice = normalize_choice(raw_choice)

        if choice == "6":
            print("\n" * 2, end='')
            print_colored_line(_('exit'), padding_spaces, lambda i: BOLD_ITALIC)
            break

        if choice == "5":
            settings_menu()
            clear_screen()
            continue

        if choice == "1":
            hawk_spotify_song_base()
            clear_screen()
            continue
        elif choice == "2":
            hardware_upgrade_submenu()
            clear_screen()
            continue
        elif choice == "3":
            hack_russian_banks_submenu()
            clear_screen()
            continue
        elif choice == "4":
            clear_screen()
            print("\n" * 2, end='')
            msg = "короче ебашишь 4 пакетика чая, чем то накрываешь, лостаешь пакетики и добавьяешь щепотку панчунеза и готов"
            print_colored_line(msg, padding_spaces, lambda i: BOLD_ITALIC)
            print()
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            input()
            clear_screen()
            continue
        else:
            print("\n" * 2, end='')
            print_colored_line(_('invalid_input'), padding_spaces, lambda i: BOLD_ITALIC)
            print_colored_line(_('press_enter'), padding_spaces, lambda i: BOLD_ITALIC)
            try:
                input()
            except KeyboardInterrupt:
                print()
                sys.exit(0)
            clear_screen()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(RESET, end='')
        sys.exit(0)