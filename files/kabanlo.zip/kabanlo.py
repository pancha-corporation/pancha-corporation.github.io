import json
import datetime
from typing import Dict, List, Optional

class AdvancedPigFarm:
    def __init__(self, farm_name: str = "Моя свиноферма"):
        self.farm_name = farm_name
        self.pig_groups = {}
        self.financial_records = []
        self.health_records = []
        
        # Более детальные параметры
        self.avg_weights = {
            'поросенок': {'min': 10, 'max': 25, 'avg': 15},
            'подсвинок': {'min': 40, 'max': 80, 'avg': 60},
            'взрослая_свинья': {'min': 100, 'max': 150, 'avg': 120},
            'свиноматка': {'min': 150, 'max': 200, 'avg': 170}
        }
        
        self.price_params = {
            'base_price_per_kg': 150,
            'price_premiums': {
                'поросенок': 0.8,  # 80% от базовой цены
                'подсвинок': 0.9,  # 90% от базовой цены
                'взрослая_свинья': 1.0,  # 100% от базовой цены
                'свиноматка': 1.2  # 120% от базовой цены
            }
        }
        
        # Нормы кормления (кг/гол/день)
        self.feed_rates = {
            'поросенок': 1.2,
            'подсвинок': 2.5,
            'взрослая_свинья': 3.0,
            'свиноматка': 3.5
        }
        self.feed_price_per_kg = 25  # руб/кг корма

    def add_pig_group(self, group_name: str, count: int, category: str,
                      purchase_price: float = None, purchase_date: str = None):
        """Добавить группу свиней с финансовой информацией"""
        if category not in self.avg_weights:
            available_categories = ", ".join(self.avg_weights.keys())
            print(f"Неизвестная категория: {category}. Доступные: {available_categories}")
            return False
        
        self.pig_groups[group_name] = {
            'count': count,
            'category': category,
            'avg_weight': self.avg_weights[category]['avg'],
            'purchase_price': purchase_price,
            'purchase_date': purchase_date or datetime.datetime.now().strftime("%Y-%m-%d"),
            'creation_date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            'vaccinated': False,
            'notes': ''
        }
        
        # Запись финансовой операции
        if purchase_price:
            self._add_financial_record(
                "purchase",
                f"Покупка группы '{group_name}'",
                -purchase_price,
                purchase_date
            )
        
        print(f"✅ Группа '{group_name}' добавлена: {count} голов категории '{category}'")
        return True

    def remove_pig_group(self, group_name: str, count: int = None,
                         reason: str = "продажа", price: float = None):
        """Удалить группу или часть свиней"""
        if group_name not in self.pig_groups:
            print(f"❌ Группа '{group_name}' не найдена")
            return False
        
        if count is None:
            # Удалить всю группу
            removed_count = self.pig_groups[group_name]['count']
            del self.pig_groups[group_name]
            print(f"✅ Группа '{group_name}' полностью удалена ({removed_count} голов)")
        else:
            # Удалить часть свиней
            if count > self.pig_groups[group_name]['count']:
                print(f"❌ Нельзя удалить {count} свиней, в группе только {self.pig_groups[group_name]['count']}")
                return False
            
            self.pig_groups[group_name]['count'] -= count
            print(f"✅ Удалено {count} свиней из группы '{group_name}'")
            
            # Запись финансовой операции при продаже
            if price and reason == "продажа":
                self._add_financial_record(
                    "sale",
                    f"Продажа {count} голов из '{group_name}'",
                    price
                )
        
        return True

    def update_group_health(self, group_name: str, vaccinated: bool = None, notes: str = None):
        """Обновить информацию о здоровье группы"""
        if group_name not in self.pig_groups:
            print(f"❌ Группа '{group_name}' не найдена")
            return
        
        if vaccinated is not None:
            self.pig_groups[group_name]['vaccinated'] = vaccinated
            status = "вакцинирована" if vaccinated else "не вакцинирована"
            print(f"✅ Группа '{group_name}' отмечена как {status}")
        
        if notes:
            self.pig_groups[group_name]['notes'] = notes

    def calculate_total_weight(self) -> float:
        """Рассчитать общий вес всех свиней"""
        total_weight = 0
        for group in self.pig_groups.values():
            total_weight += group['count'] * group['avg_weight']
        return total_weight

    def calculate_estimated_value(self) -> float:
        """Рассчитать оценочную стоимость с учетом категорий"""
        total_value = 0
        for group in self.pig_groups.values():
            category = group['category']
            weight = group['count'] * group['avg_weight']
            price_multiplier = self.price_params['price_premiums'].get(category, 1.0)
            category_value = weight * self.price_params['base_price_per_kg'] * price_multiplier
            total_value += category_value
        return total_value

    def calculate_feed_requirements(self, days: int = 30) -> Dict:
        """Рассчитать потребность в кормах и стоимость"""
        total_feed = 0
        total_cost = 0
        feed_by_category = {}
        
        for group_name, group_data in self.pig_groups.items():
            category = group_data['category']
            feed_rate = self.feed_rates[category]
            category_feed = group_data['count'] * feed_rate * days
            category_cost = category_feed * self.feed_price_per_kg
            total_feed += category_feed
            total_cost += category_cost
            
            feed_by_category[group_name] = {
                'feed_kg': category_feed,
                'cost_rub': category_cost,
                'daily_per_head': feed_rate
            }
        
        return {
            'total_feed_kg': total_feed,
            'total_cost_rub': total_cost,
            'daily_cost_rub': total_cost / days,
            'by_category': feed_by_category
        }

    def calculate_profitability(self) -> Dict:
        """Рассчитать показатели рентабельности"""
        total_value = self.calculate_estimated_value()
        total_investment = sum(group.get('purchase_price', 0) for group in self.pig_groups.values())
        
        # Расчет кормов на 6 месяцев
        feed_6_months = self.calculate_feed_requirements(180)
        total_feed_cost = feed_6_months['total_cost_rub']
        
        total_costs = total_investment + total_feed_cost
        potential_profit = total_value - total_costs
        profitability = (potential_profit / total_costs * 100) if total_costs > 0 else 0
        
        return {
            'total_investment': total_investment,
            'current_value': total_value,
            'feed_costs_6months': total_feed_cost,
            'total_costs': total_costs,
            'potential_profit': potential_profit,
            'profitability_percent': profitability
        }

    def _add_financial_record(self, operation_type: str, description: str,
                              amount: float, date: str = None):
        """Добавить запись о финансовой операции"""
        record = {
            'date': date or datetime.datetime.now().strftime("%Y-%m-%d"),
            'type': operation_type,
            'description': description,
            'amount': amount
        }
        self.financial_records.append(record)

    def display_detailed_report(self):
        """Показать детальный отчет"""
        print("\n" + "=" * 60)
        print(f"ДЕТАЛЬНЫЙ ОТЧЕТ: {self.farm_name}")
        print("=" * 60)
        
        if not self.pig_groups:
            print("На ферме нет свиней")
            return
        
        total_pigs = 0
        total_weight = 0
        
        # Отчет по группам
        print("\n📊 ГРУППЫ СВИНЕЙ:")
        print("-" * 60)
        
        for group_name, data in self.pig_groups.items():
            group_weight = data['count'] * data['avg_weight']
            total_pigs += data['count']
            total_weight += group_weight
            
            vaccinated_status = "✅" if data['vaccinated'] else "❌"
            
            print(f"\n🏷️ Группа: {group_name}")
            print(f"   Категория: {data['category']}")
            print(f"   Количество: {data['count']} голов")
            print(f"   Средний вес: {data['avg_weight']} кг")
            print(f"   Общий вес: {group_weight} кг")
            print(f"   Вакцинация: {vaccinated_status}")
            
            if data.get('purchase_price'):
                print(f"   Стоимость покупки: {data['purchase_price']:,.0f} руб")
            if data.get('notes'):
                print(f"   Примечания: {data['notes']}")
        
        # Финансовый отчет
        estimated_value = self.calculate_estimated_value()
        print(f"\n💰 ФИНАНСОВЫЕ ПОКАЗАТЕЛИ:")
        print("-" * 40)
        print(f"Оценочная стоимость: {estimated_value:,.0f} руб")
        
        profitability = self.calculate_profitability()
        print(f"Общие инвестиции: {profitability['total_investment']:,.0f} руб")
        print(f"Потенциальная прибыль: {profitability['potential_profit']:,.0f} руб")
        print(f"Рентабельность: {profitability['profitability_percent']:.1f}%")
        
        # Расчет кормов
        feed_info = self.calculate_feed_requirements(30)
        print(f"\n🌾 РАСХОД КОРМОВ (за 30 дней):")
        print("-" * 40)
        print(f"Общее количество корма: {feed_info['total_feed_kg']:,.0f} кг")
        print(f"Стоимость кормов: {feed_info['total_cost_rub']:,.0f} руб")
        print(f"Ежедневные затраты: {feed_info['daily_cost_rub']:,.0f} руб/день")
        
        # Итоговая статистика
        print(f"\n📈 ОБЩАЯ СТАТИСТИКА:")
        print("-" * 40)
        print(f"Общее количество свиней: {total_pigs} голов")
        print(f"Общий вес: {total_weight:,.0f} кг")
        
        if total_pigs > 0:
            print(f"Средний вес на голову: {total_weight / total_pigs:.1f} кг")
        
        # Распределение по категориям
        print(f"\n📋 РАСПРЕДЕЛЕНИЕ ПО КАТЕГОРИЯМ:")
        print("-" * 40)
        
        categories = {}
        for group in self.pig_groups.values():
            cat = group['category']
            categories[cat] = categories.get(cat, 0) + group['count']
        
        for cat, count in categories.items():
            percentage = (count / total_pigs) * 100
            print(f"{cat}: {count} голов ({percentage:.1f}%)")

    def save_to_file(self, filename: str = None):
        """Сохранить данные фермы в файл"""
        if filename is None:
            filename = f"{self.farm_name.replace(' ', '_')}.json"
        
        data = {
            'farm_name': self.farm_name,
            'pig_groups': self.pig_groups,
            'financial_records': self.financial_records,
            'save_date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ Данные сохранены в файл: {filename}")

    def load_from_file(self, filename: str):
        """Загрузить данные фермы из файла"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self.farm_name = data.get('farm_name', self.farm_name)
            self.pig_groups = data.get('pig_groups', {})
            self.financial_records = data.get('financial_records', [])
            
            print(f"✅ Данные загружены из файла: {filename}")
            return True
        except Exception as e:
            print(f"❌ Ошибка загрузки файла: {e}")
            return False

# Пример использования улучшенного класса
def main():
    # Создаем ферму
    farm = AdvancedPigFarm("Свиноферма 'Удачная'")
    
    # Добавляем группы свиней с финансовой информацией
    farm.add_pig_group("Основное стадо", 45, "взрослая_свинья", 500000)
    farm.add_pig_group("Свиноматки", 10, "свиноматка", 200000)
    farm.add_pig_group("Молодняк 1", 25, "подсвинок", 150000)
    farm.add_pig_group("Молодняк 2", 35, "подсвинок", 210000)
    farm.add_pig_group("Новые поросята", 60, "поросенок", 180000)
    
    # Отмечаем вакцинацию
    farm.update_group_health("Основное стадо", vaccinated=True, notes="Вакцинированы 15.01.2024")
    farm.update_group_health("Свиноматки", vaccinated=True)
    
    # Показываем детальный отчет
    farm.display_detailed_report()
    
    # Сохраняем данные
    farm.save_to_file()
    
    # Демонстрация расчета кормов
    print("\n" + "=" * 50)
    print("ДЕТАЛЬНЫЙ РАСЧЕТ КОРМОВ:")
    feed_info = farm.calculate_feed_requirements(30)
    for group_name, info in feed_info['by_category'].items():
        print(f"{group_name}: {info['feed_kg']:.0f} кг корма, стоимость: {info['cost_rub']:.0f} руб")

if __name__ == "__main__":
    main()
